# README gameplay clips

These are selected examples from six new recordings of the released `pocket`
agent, running stock Crafter 1.8.3. They are illustrations, not a new benchmark
sample. The recorded episodes continued until death; the two diamond clips
stop at collection. No agent rules were changed for these recordings.

| Clip | Seed | Actions shown | Playback |
|---|---:|---:|---|
| [Quick diamond](assets/easy-diamond.gif) | 205000138 | 0–67 | 9.8 seconds including pauses |
| [Hard-earned diamond](assets/long-diamond-hunt.gif) | 205000123 | 0–1,862 | 29.9-second timelapse |
| [Fatal shoreline fight](assets/shoreline-death.gif) | 205000002 | 425–489 | 9.5 seconds including pauses |

## Why these three?

The quick run completes the resource and tool chain and collects diamond in
67 actions. Resources are close enough that it can finish before survival
becomes a major distraction.

The difficult run makes its iron pickaxe at action 90 but doesn't get diamond
until action 1,862. Before collection, it mines 87 stone, eats 9 cows and wakes
from sleep 17 times. Its health drops as low as 1 and recovers. This was the
longest successful diamond hunt among the six recordings, chosen from worlds
with late successes in the saved results. We haven't defined a measure that
would establish it as the most complex possible game.

The failed run fights along a narrow strip of shoreline. It starts the clip
with full health and dies at action 489, without diamond. Water and trees
leave little room to move. The clip includes the terminal frame with zero
health; it is not merely a close call.

## What you see

The game area is the exact returned 64×64 RGB observation, including the HUD
and nighttime darkness, enlarged fourfold with nearest-neighbor sampling.
GIF palette conversion is the only color conversion. Labels are outside the
game image and are not inputs to the agent. No extra `env.render()` call is
made, since that can change Crafter's random state.

The quick and death clips show every action at 10 actions per second. The long
hunt shows every eighth action, then every action for its final 40 actions.
The first frame pauses for 0.7 seconds and the last for 2.5 seconds. The step
counter shows the original action number, not the GIF frame number.

The files total about 5.4 MB. Each GIF has a JSON file alongside it with seed,
episode results, included frame numbers, playback duration and hashes of the
GIF, full action sequence and original RGB recording. `summary.achievements`
describes the full episode, not just the excerpt.
Crafter artwork is covered by its [MIT notice](assets/CRAFTER_LICENSE.md).

## Make your own

For an ordinary full-episode GIF, use the existing runner:

```bash
crafter-symbolic --seed 205000138 --record-dir runs/my-gifs
```

To make labeled excerpts like the README, run from the repository root after
installation. Recording saves lossless frames and event logs in the ignored
`runs/` folder. Evaluation information is only logged; the agent still gets
only RGB and the previous reward.

```bash
python scripts/record_gallery.py --seeds 205000138 205000123 205000002 --workers 3 --output runs/gallery
python scripts/render_gallery.py --input runs/gallery/205000138.npz --output runs/quick.gif --title 'Quick diamond' --end diamond
python scripts/render_gallery.py --input runs/gallery/205000123.npz --output runs/hunt.gif --title 'The long diamond hunt' --end diamond --stride 8
python scripts/render_gallery.py --input runs/gallery/205000002.npz --output runs/death.gif --title 'A fatal shoreline fight' --start 425 --end death
```

Use fresh output paths. A seed does not guarantee an identical trajectory
across stock Crafter processes: object iteration order can change events.
Check the new recording's JSON before choosing clip ranges. The renderer
refuses `--end diamond` when that recording did not collect one.

The other three candidate seeds were 206000047, 205000234 and 205000041.
Only the two displayed successes collected diamond in this six-recording
batch. None of these results were added to the published benchmark totals.

[Back to README](../README.md)
