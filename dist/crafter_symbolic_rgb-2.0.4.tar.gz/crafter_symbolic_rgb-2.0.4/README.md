# Crafter Symbolic

**A diamond-first, RGB-only symbolic agent for [Crafter](https://github.com/danijar/crafter).**
Runs locally on CPU. No neural weights, GPU, API keys or human decisions during play.

## Why?

We wanted to find out **how high Crafter score—and especially diamond success—
could go within the game's 10,000-step episode horizon**. A symbolic heuristics
solver gave us something transparent to iterate on: analyze failures, improve
survival/exploration/planning, and test frozen candidates on fresh games.
Success probability came first; faster diamonds were a secondary objective.

The recommended `pocket` agent reached **69.98 Score and 55.47% diamond success
(213/384 fresh episodes)**. This is a case study in attainable symbolic-agent
capability, not a claim of state-of-the-art performance or optimality.

## Run, watch, record

From this repository, using **Python 3.11** (tested):

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install ".[viewer]"  # Installs Crafter too; omit [viewer] for headless use.

crafter-symbolic --show --seed 0  # Live view; Space pauses, Escape stops.
crafter-symbolic --seed 0         # Headless episode.
crafter-symbolic --seed 0 --record-dir runs/demo  # Save a GIF.
crafter-symbolic --episodes 100 --workers 4 --seed 1000 --output runs/batch.json
```

Viewing and GIFs are opt-in. Use fresh output paths. Episodes continue after
diamond until death or 10,000 actions; batch JSON includes **all 22 achievement
rates, Crafter Score, diamond success and time-to-diamond statistics**.

[Full usage, CLI options and troubleshooting](docs/USAGE.md) ·
[Python integration example](examples/play.py)

## Context, not a leaderboard

Published context, checked **2026-09-05**, without a training-budget cutoff.
**Not matched evaluations or evidence of superiority over humans or other
agents:** priors, inputs and aggregation differ.

| Agent | Crafter Score | Diamond success | Setting |
|---|---:|---:|---|
| This release: `pocket` | 69.98 | 55.47% | Stock Crafter, 64×64 RGB |
| [Human experts](https://arxiv.org/abs/2109.06780v2) | 50.5 ± 6.8 | 12% | Original Crafter |
| [EMERALD](https://proceedings.mlr.press/v267/burchi25a.html) | 58.1 | 0.5% | Crafter, 64×64 RGB |
| [C-VPT (large)](https://arxiv.org/html/2508.13530v1) | 61.4 ± 4.7 | ≈13%* | Reported Crafter protocol, 144×144 RGB |

*Approximate reading of Figure 11. Human Score is group-averaged (pooled: 52.05).
Our/human/EMERALD limits are 10,000 steps per episode; C-VPT states the standard
protocol, not independently reproduced here.

Higher related results within **10,000 steps per episode**: **CrafterDojo's
expert: 97.5 Score / 71% diamond; SCALAR: 88.2% diamond**. Both use
**Craftax-Classic** (a reimplementation, not identical Crafter) and **symbolic
inputs** (game facts supplied directly). Our controller derives its symbols
from RGB in stock Crafter. SCALAR also guarantees a diamond per map.

These remain valuable results; we have not isolated how much of the gap comes
from policy, input or world differences.
[Sources and protocol audit](docs/LITERATURE_COMPARISON.md).

## Code and details

- **Use the agent:** [`Agent.act(rgb, reward)`](src/crafter_symbolic/agent.py)
  returns an integer action (0–16), with episode-local memory.
- **Understand it:** [frozen policy and RGB decoder](src/crafter_symbolic/_policy/) ·
  [architecture and observation contract](docs/ARCHITECTURE.md).
- **Run/export:** [CLI](src/crafter_symbolic/cli.py) ·
  [viewer](src/crafter_symbolic/viewer.py) · [metrics](src/crafter_symbolic/metrics.py).
- **Inspect the evidence:** [benchmarks and uncertainty](docs/BENCHMARKS.md) ·
  [experiments, failures and limitations](docs/AUDIT.md).
- **Verify/contribute/publish:** [tests](tests/) ·
  [verification](docs/VERIFICATION.md) · [contributing](CONTRIBUTING.md) ·
  [GitHub publishing](docs/PUBLISHING.md).

The policy uses only returned RGB, previous reward and its own history—no global
map or hidden nighttime labels. Hand-coded mechanics/textures are external
knowledge. Survival remains imperfect; the neural replica is not included.

[MIT license](LICENSE) · [Changelog](CHANGELOG.md)
