# Changelog

## 2.0.2 — 2026-09-05

- Substantial public README with installation, viewing, GIFs, API, CLI options,
  batch output, benchmark interpretation and troubleshooting.
- Owner-approved MIT license and package license metadata.
- Repository checks, contributor/publishing guides and GitHub issue/PR templates.
- Repository-ready source distribution; frozen policy and measured scores unchanged.

## 2.0.1 — 2026-09-05

- Optional Pygame live viewer with pause, stop and pixel enlargement.
- Live/GIF playback-speed control; viewing and recording remain opt-in.
- Twenty release tests passed, including offscreen drawing and event handling.
- No policy changes; 2.0.0 distribution artifacts preserved locally.

## 2.0.0 — 2026-09-05

- Standalone RGB-only package with default pocket and optional combined controller.
- Integer-action Python API, stock-Crafter runner, GIF export and multiprocessing.
- Portable benchmark evidence, observation-contract audit and frozen-source hashes.
- Fifteen initial package tests and six complete episode-equivalence checks passed.

Historical 1.0 used privileged local simulator labels through nighttime
corruption. It is not the RGB-only release, and its scores are not included
in the current benchmark pools. See [the audit](docs/AUDIT.md).
