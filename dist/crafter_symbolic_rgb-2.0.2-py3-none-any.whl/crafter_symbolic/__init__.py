"""RGB-only symbolic agent for unmodified Crafter 1.8.3."""
from .agent import Agent, ACTION_NAMES

__version__ = '2.0.2'
__all__ = ['Agent', 'ACTION_NAMES', '__version__']
