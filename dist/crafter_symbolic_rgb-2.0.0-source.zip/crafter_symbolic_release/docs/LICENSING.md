# Licensing and publication

The original agent code has not been assigned an open-source license in this
packaging task. The owner should choose the project license before public
distribution; this package does not grant reuse rights by assumption.

Crafter is installed as a dependency, not vendored here. Its source and game
assets are provided by Danijar Hafner's project under its
[MIT license](https://github.com/danijar/crafter/blob/main/LICENSE). NumPy,
Pillow, imageio, opensimplex and ruamel.yaml retain their respective licenses.
No paper PDF, human gameplay archive, neural weights, credentials, or private
machine paths are included in this repository-style folder.

Before pushing publicly:

1. Choose an owner-approved project license and add its LICENSE file/metadata.
2. Review README, audit, and benchmark caveats; do not call this a 1M-step RL result.
3. Run the tests and evidence verifier using the locked dependency environment.
4. Initialize a Git repository here if desired, choose a remote, and push.

No remote repository was created and no upload was performed during packaging.
