# Crafter Symbolic — RGB-only release 2.0

An autonomous, non-neural agent for [the original Crafter benchmark](https://github.com/danijar/crafter).
It builds tools, manages food/water/sleep, explores for diamond, and then pursues
the remaining achievements. Input: the exact **64×64 RGB frame**. Output: one
of Crafter's **17 integer actions**. Memory is ordinary episode-local Python state.

**Recommended agent: `pocket`.** This is our retained `combined` diamond
controller plus natural protected-crop handling **after** diamond. Its two
completed fresh stock batches contain **213/384 diamonds (55.47%)**, with
**69.98 Crafter score** from their pooled achievement rates. The 256-episode
batch scored 69.38; the separate 128-episode batch scored 71.12. These are
measured results, not a guarantee or an estimate of the optimal attainable score.
See [benchmarks and uncertainty](docs/BENCHMARKS.md) and the [full audit](docs/AUDIT.md).

No training, model checkpoint, GPU, API key, network call during play, or lab
directory is needed. No global map, simulator coordinates, hidden enemy state,
or perfect nighttime semantic labels enter the policy. Public game textures
and mechanics are strong hand-coded priors; this is an **external-knowledge**
agent, not a competitor under the paper's 1M-step RL training budget.

## Install and run

From this folder, with Python 3.11 or newer:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install .
crafter-symbolic --seed 0 --episodes 1
```

On Windows, activate with `.venv\Scripts\activate` instead. Installation also
installs `crafter==1.8.3` if missing. The tested dependency set is available with
`python -m pip install -r requirements.lock .`. Python 3.11 on macOS arm64 is
the locally verified platform; Linux CI is configured but has not yet run remotely.

Already have the paper's Crafter repository installed? Use the same command:
`pip install .` accepts an installed package reporting version 1.8.3. Keep its
default assets, 64×64 RGB size, 9×9 view including HUD, and 64×64 world. Other
renderers, asset packs, frame stacking, action repeats and Gymnasium wrappers
are not verified. Stock `crafter.Env` does not require installing Gym.

```bash
# Full episodes, six independent CPU workers; save all 22 achievement rates.
crafter-symbolic --episodes 100 --workers 6 --seed 1000 --output runs/results.json

# Record exact returned frames, without calling render() a second time.
crafter-symbolic --seed 0 --record-dir runs/demo --output runs/demo.json

# Short packaging smoke only, not a benchmark score.
python -m crafter_symbolic --length 20
```

Output files are never overwritten. Interrupted runs retain their completed
rows in a `.jsonl` journal but are not reported as completed benchmark batches.
`--variant combined` exposes the simpler retained comparison agent. The default
does **not** include rejected broad combat changes, pre-diamond sword investment,
moving-food experiments, or an unfinished learned selector.

## Python API

```python
import crafter
from crafter_symbolic import Agent

env = crafter.Env(seed=0, length=10000)
rgb, reward = env.reset(), 0.0
agent = Agent()  # default: pocket

while True:
    action = agent.act(rgb, reward)  # int 0..16
    rgb, reward, done, info = env.step(action)
    if done:
        print(info["achievements"])  # evaluator output only, never an agent input
        break
```

Use a fresh `Agent()` or `agent.reset()` for every episode. Call `act` exactly
once per returned frame, beginning at reset, with a `numpy.uint8` array of shape
`(64, 64, 3)`. `ACTION_NAMES[action]` gives its readable name. Do not feed `info`,
semantic debug maps, private player fields, or an additional `env.render()` call
to the agent. Night rendering consumes randomness; re-rendering is not harmless.

## What's inside

- [Architecture and observation contract](docs/ARCHITECTURE.md): primitives,
  memory, uncertainty, and where approximate planning is used.
- [Full research audit](docs/AUDIT.md): accepted/rejected ideas, corrections,
  stopped work, neural translation status, and limits of the evidence.
- [Benchmark record](docs/BENCHMARKS.md): full achievement profiles, source hashes,
  fresh versus development results, and human-comparison caveats.
- [Release verification](docs/VERIFICATION.md): clean installation, tests and
  complete-episode equivalence checks.
- `evidence/`: portable episode summaries and policy provenance; no private
  machine paths, neural weights, or bulk training data.
- `tests/`: API, observation-boundary, perception, metric, and runner checks.
- `examples/play.py`: minimal stock-environment integration.

```bash
python -m unittest discover -s tests -v
python scripts/verify_evidence.py
python -m pip wheel --no-deps . --wheel-dir dist
```

The policy transplant preserves the measured logic; internal imports were
namespaced and only the old configuration/action constants were extracted.
The historical privileged-vision release 1.0 is **not** this package.

This folder can become its own repository. Nothing has been published or
pushed remotely. A project license has deliberately not been assigned on the
owner's behalf; see [licensing and publication checklist](docs/LICENSING.md).
