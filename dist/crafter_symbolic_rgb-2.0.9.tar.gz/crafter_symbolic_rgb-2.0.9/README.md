# Crafter Symbolic

A hand-written Python agent for [Crafter](https://github.com/danijar/crafter).
It collects resources, crafts tools, explores and tries to stay alive—without
a neural network or an online service.

We built it to test how far symbolic heuristics could push diamond success
and Crafter Score within the game's **10,000-action limit**. We improved the
rules by studying failures and testing changes. Success across episodes came
first; faster diamond collection came second.

The released `pocket` agent collected diamonds in **213/384 games (55.47%)**,
with a **Crafter Score of 69.98**. All 384 games eventually ended in death.
These are measured results, not an upper bound.

It reads the returned 64×64 RGB image and keeps its own memory. It uses public
game rules and textures, but receives no global map or hidden nighttime
labels. Everything runs on CPU.

## Watch it play

![Quick diamond: collected at action 67](docs/assets/easy-diamond.gif)
![Long diamond hunt: collected at action 1862](docs/assets/long-diamond-hunt.gif)
![Failed hunt: the full game, ending in death at action 489](docs/assets/shoreline-death.gif)

In order: a quick diamond in **67 actions**, a long successful hunt in
**1,862 actions**, and a failed **489-action** game. The first two clips stop
at diamond collection; the third shows the whole game from reset to death.

These are selected examples, not benchmark results. Playback speeds differ
and are labeled on each clip; compare action counts, not video duration.
[Seeds, playback details and recording instructions](docs/GAMEPLAY.md).

## Run it

From this folder, using Python 3.11:

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install ".[viewer]"  # Installs Crafter and the optional viewer.
crafter-symbolic --show --seed 0   # Space pauses; Escape stops.
```

Run without a window, save a full-game GIF, or evaluate a batch:

```bash
crafter-symbolic --seed 0
crafter-symbolic --seed 0 --record-dir runs/demo
crafter-symbolic --episodes 100 --workers 4 --seed 1000 --output runs/batch.json
```

Batch output includes all 22 achievement rates, Crafter Score and diamond
timing. Episodes continue after collecting diamond, ending at death or 10,000
actions. Use fresh output paths; existing files are protected. Omit the
`[viewer]` extra for a headless-only installation.

[All options and troubleshooting](docs/USAGE.md) ·
[Python API example](examples/play.py)

## Results in context

Training budgets, inputs and evaluation procedures differ across these papers.
This is context, not a matched leaderboard or a claim of state-of-the-art
performance. References checked on 2026-09-05.

| Agent | Crafter Score | Diamond success | Game and input |
|---|---:|---:|---|
| This repo: `pocket` | 69.98 | 55.47% | Stock Crafter, 64×64 RGB |
| [Human experts](https://arxiv.org/abs/2109.06780v2) | 50.5 ± 6.8 | 12% | Original Crafter |
| [EMERALD](https://proceedings.mlr.press/v267/burchi25a.html) | 58.1 | 0.5% | Crafter, 64×64 RGB |
| [C-VPT (large)](https://arxiv.org/html/2508.13530v1) | 61.4 ± 4.7 | ≈13%* | Crafter, 144×144 RGB |

*C-VPT's diamond rate is estimated from Figure 11. Its paper states the
standard Crafter protocol; we haven't reproduced its evaluation. The other
rows use 10,000-action limits. Human Score is averaged across groups of games.

Craftax-Classic is a separate implementation. CrafterDojo's expert reports
97.5 Score / 71% diamonds; SCALAR reports 88.2% diamonds. Both use 10,000-action
limits and receive symbolic game facts directly; SCALAR also guarantees a
diamond per map. These are not stock-RGB comparisons, and the cause of the
performance gap is not established.
[Sources and comparison details](docs/LITERATURE_COMPARISON.md).

## Code and further reading

- [Agent API](src/crafter_symbolic/agent.py): `Agent.act(rgb, reward)` returns
  an action from 0 to 16; `reset()` clears episode memory.
- [Controller and decoder](src/crafter_symbolic/_policy/) ·
  [Code map](docs/CODE_MAP.md) · [Architecture](docs/ARCHITECTURE.md).
- [Runner](src/crafter_symbolic/cli.py) · [Viewer](src/crafter_symbolic/viewer.py) ·
  [Scoring](src/crafter_symbolic/metrics.py).
- [Benchmark data and uncertainty](docs/BENCHMARKS.md) ·
  [Research history](docs/AUDIT.md) · [Input audit and known limitations](docs/FINAL_INPUT_AUDIT.md).
- [Tests](tests/) · [Verification](docs/VERIFICATION.md) ·
  [Contributing](CONTRIBUTING.md) · [Publishing to GitHub](docs/PUBLISHING.md).

GPT 5.6 Sol and GPT 6 Astra (xhigh) in Codex were used to develop and iterate
on the agent. Neither runs during gameplay. The unfinished neural-agent work
is not included.

[MIT license](LICENSE) · [Changelog](CHANGELOG.md)
