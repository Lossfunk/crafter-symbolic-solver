## Summary

What changed, and why?

## Scope

- Does this change policy behavior or the observation contract?
- Are any reported benchmark numbers affected?

## Verification

- [ ] Relevant tests pass.
- [ ] Repository/documentation checks pass.
- [ ] Frozen policy hashes are unchanged, or new policy provenance is explicitly documented.
- [ ] No credentials, private paths, generated runs, or bulk artifacts are included.

Include exact commands and any limitations of the verification.
